int main()
{
  int y;
  int z = y * 2;
  int x = z * 10;
  printf ("x = %d\n", x);
}
