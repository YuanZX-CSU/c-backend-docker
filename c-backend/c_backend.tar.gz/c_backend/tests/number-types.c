int main() {
  long long int a = 1234567890123456789L;

  char b = (char)a;
  short c = (short)a;
  int d = (int)a;
  long int e = (long int)a;

  unsigned char f = (unsigned char)a;
  unsigned short g = (unsigned short)a;
  unsigned int h = (unsigned int)a;
  unsigned long int i = (unsigned long int)a;
  unsigned long long int j = (unsigned long long int)a;

  long double k = 3.1415926535897932384626433832795028841971693993751058209749L;
  double l = (double)k;
  float m = (float)k;

  return 0;
}
