#include <stdlib.h>
#include<string.h>

int main() {
    char sentences[][100] = {"abc is a word","he he","   ","d ab   ","  x","asd324","","a"};
    char ans[][100] = { "word", "he","","ab","x","asd324","","a"};
    return 0;
}
