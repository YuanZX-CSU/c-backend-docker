#include <stdlib.h>

int main() {
  int* x = malloc(2*sizeof(*x));
}
