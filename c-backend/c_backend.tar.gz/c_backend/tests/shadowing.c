int x = 111;
void main() {
  int x = 222;
  {
    int x = 333;
  }
}
