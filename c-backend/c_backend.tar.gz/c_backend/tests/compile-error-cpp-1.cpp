#include <stdlib>

int main() {
  int* x = malloc(2*sizeof(*x));
}
