// from an actual bug report!
#include <stdio.h>

int main() {
  printf("Hola\n");
}
