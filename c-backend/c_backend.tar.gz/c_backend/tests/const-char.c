int main() {
  const char* x = "abc";
  const char* const y = x;
}
