int main() {
  // inception?!?
  int x = 42;
  int *y = &x;
  int **z = &y;
  int ***wtf = &z;
}
