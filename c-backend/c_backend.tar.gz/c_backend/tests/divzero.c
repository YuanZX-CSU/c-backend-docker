int main() {
  float x = 5.0f / 0.0f;
}
