int main() {
  int a = 150;
  char b = (char)a;
  return 0;
}
