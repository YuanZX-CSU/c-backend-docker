int x[] = {1,2,3,4,5};

void foo(int* a) {
}

int main() {
  foo(x);
}
