typedef unsigned char BYTE;
typedef long long int LLI;
typedef int* INT_PTR;
typedef char* C_STRING;

int main() {
  LLI x = 1234567890;
  BYTE y[5] = {10,20,30,40,50};
  int foo = 42;
  INT_PTR foo_ptr = &foo;
  C_STRING name = "Philip\tGuo\n";
}
