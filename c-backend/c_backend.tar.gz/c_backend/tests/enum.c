// from a bug report:
enum color
{
  RED,
  ORANGE,
  YELLOW,
  GREEN,
  BLUE,
  INDIGO,
  VIOLET,
};

int main() {
  enum color my_color = RED;
  return 0;
}
